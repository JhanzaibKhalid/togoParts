import 'package:flutter/material.dart';
import 'package:togo_parts/options.dart';
import 'package:togo_parts/splash.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp( MyApp());
}

class MyApp extends StatefulWidget {

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Splash(),
    );
  }
}
class MyWebViewWidget extends StatefulWidget {


  @override
  State<MyWebViewWidget> createState() => _MyWebViewWidgetState();
}

class _MyWebViewWidgetState extends State<MyWebViewWidget> {
  List list=["Rides","Magazine","Forum","Bike Shops","Careers","Advertise on MyWebViewWidget","About MyWebViewWidget","Terms of Service"];
  List<Widget> list1=<Widget>[
    Image.asset("images/rides_icon@3x.png"),
    Image.asset("images/magazine_icon@3x.png"),
    Image.asset("images/forum_icon@3x.png"),
    Image.asset("images/bike_shops_icon@3x.png"),
    Image.asset("images/careers_icon@3x.png"),
    Image.asset("images/advertise_icon@3x.png"),
    Image.asset("images/about_icon@3x.png"),
    Image.asset("images/terms_services_icon@3x.png"),
  ];
  List urls=["https://www.togoparts.com/","https://www.togoparts.com/bikeprofile/trides","https://www.togoparts.com/marketplace/browse","https://www.togoparts.com/marketplace/create/","https://www.togoparts.com/bikeprofile/trides"];
late WebViewController controler;
int selectedIndex=0;
late bool b=true;
  @override
  void initState() {

    // TODO: implement initState
    super.initState();
   controler=WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..setNavigationDelegate(
        NavigationDelegate(
onPageStarted: (a){},
onProgress: (a){},
onPageFinished: (a){},

    ));
    controler.loadRequest(Uri.parse(urls[selectedIndex]));

  }
  @override
  Widget build(BuildContext context) {
    return

      Scaffold(
      body:
      Padding(
        padding: const EdgeInsets.only(top: 12.0),

        child:b?WebViewWidget(controller: controler,):Market(),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.red,
        currentIndex: selectedIndex,

        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home),label:"Home",backgroundColor: Colors.red),
          BottomNavigationBarItem(icon: Icon(Icons.bike_scooter),label:"Rides",backgroundColor: Colors.brown),
          BottomNavigationBarItem(icon: Icon(Icons.shop_outlined),label:"Market",backgroundColor: Colors.yellow),
          BottomNavigationBarItem(icon: Icon(Icons.shop_two_outlined),label:"Search",backgroundColor: Colors.black),
          BottomNavigationBarItem(icon: Icon(Icons.shop_two_outlined),label:"Search",backgroundColor: Colors.black),

        ],
        onTap: (index){
          setState(() {
            selectedIndex=index;
            controler.loadRequest(Uri.parse(urls[selectedIndex]));
            if(index==4){
              b=false;
            }
            else{
              b=true;
            }

          });

        },
      ),


    );
  }
}
