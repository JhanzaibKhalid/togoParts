import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
class Settings extends StatefulWidget {
  late int selectedIndex;
  Settings(int c){
    selectedIndex=c;
  }
  @override
  State<Settings> createState() => _Settings(selectedIndex);
}

class _Settings extends State<Settings> {
  late WebViewController controler;
  late int indexx;
  _Settings(int k){
    indexx=k;
  }
  List urls=["https://sympli.io/blog/designing-settings-page","https://www.togoparts.com/magazine/category/news/","https://www.togoparts.com/members/login.php?cb=https%3A%2F%2Fwww.togoparts.com%2Fmembers%2Flogin.php"];
  @override
  void initState() {

    // TODO: implement initState
    super.initState();
    controler=WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
          NavigationDelegate(
            onPageStarted: (a){},
            onProgress: (a){},
            onPageFinished: (a){},

          ));
    controler.loadRequest(Uri.parse(urls[indexx]));

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body:Padding(
          padding: const EdgeInsets.only(top:14.0),
          child: WebViewWidget(controller: controler),
        ));
  }
}
