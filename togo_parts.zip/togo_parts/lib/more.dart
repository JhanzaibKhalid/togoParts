import 'package:flutter/material.dart';
import 'main.dart';
import 'package:webview_flutter/webview_flutter.dart';
class Details extends StatefulWidget {
late int selectedIndex;
Details(int c){
  selectedIndex=c;
}
  @override
  State<Details> createState() => _Details(selectedIndex);
}

class _Details extends State<Details> {
  late int indexx;
  _Details(int k){
    indexx=k;
  }
  List urls=["https://www.togoparts.com/bikeprofile/trides","https://www.togoparts.com/magazine/","https://docs.google.com/forms/d/e/1FAIpQLSep0JPX8N2-D4vfOHSouY8LYU1aIhH2svBRZQ0hZZgqYuXjTw/viewform?pli=1","https://www.togoparts.com/bikeshops/list_shops.php?scid=1","https://www.togoparts.com/pages/career.php","https://docs.google.com/forms/d/e/1FAIpQLSep0JPX8N2-D4vfOHSouY8LYU1aIhH2svBRZQ0hZZgqYuXjTw/viewform?pli=1","https://www.togoparts.com/about","https://www.togoparts.com/pages/tos.php",];
  late WebViewController controler;
  @override
  void initState() {

    // TODO: implement initState
    super.initState();
    controler=WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
          NavigationDelegate(
            onPageStarted: (a){},
            onProgress: (a){},
            onPageFinished: (a){},

          ));
    controler.loadRequest(Uri.parse(urls[indexx]));

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body:Padding(
        padding: const EdgeInsets.only(top:18.0),
        child: WebViewWidget(controller: controler),
    ));
  }
}

