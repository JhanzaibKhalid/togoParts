import 'package:flutter/material.dart';
import 'package:togo_parts/more.dart';
import 'package:togo_parts/setting.dart';
import 'package:togo_parts/splash.dart';
import 'main.dart';
import 'package:webview_flutter/webview_flutter.dart';
class Market extends StatefulWidget {


  @override
  State<Market> createState() => _MarketState();
}

class _MarketState extends State<Market> {
 List urls=["https://www.togoparts.com/bikeprofile/trides","https://www.togoparts.com/magazine/","https://docs.google.com/forms/d/e/1FAIpQLSep0JPX8N2-D4vfOHSouY8LYU1aIhH2svBRZQ0hZZgqYuXjTw/viewform?pli=1","https://www.togoparts.com/bikeshops/list_shops.php?scid=1","https://www.togoparts.com/pages/career.php","https://docs.google.com/forms/d/e/1FAIpQLSep0JPX8N2-D4vfOHSouY8LYU1aIhH2svBRZQ0hZZgqYuXjTw/viewform?pli=1","https://www.togoparts.com/about","https://www.togoparts.com/pages/tos.php",];
  List list=["Rides","Magazine","Forum","Bike Shops","Careers","Advertise with us","About us","Terms of Service"];
  List<Widget> list1=<Widget>[
    Image.asset("images/rides_icon@3x.png"),
    Image.asset("images/magazine_icon@3x.png"),
    Image.asset("images/forum_icon@3x.png"),
    Image.asset("images/bike_shops_icon@3x.png"),
    Image.asset("images/careers_icon@3x.png"),
    Image.asset("images/advertise_icon@3x.png"),
    Image.asset("images/about_icon@3x.png"),
    Image.asset("images/terms_services_icon@3x.png"),
  ];
 late WebViewController controler;
 int selectedIndex=0;
 late bool a=true;
 @override
 void initState() {

   // TODO: implement initState
   super.initState();
   controler=WebViewController()
     ..setJavaScriptMode(JavaScriptMode.unrestricted)
     ..setNavigationDelegate(
         NavigationDelegate(
           onPageStarted: (a){},
           onProgress: (a){},
           onPageFinished: (a){},

         ));
   controler.loadRequest(Uri.parse(urls[selectedIndex]));

 }

 var dropdownValue ;
 List listItem=['Settings','LogIn', 'Switch Country'];
 void onSelected(BuildContext context,int item){
   switch (item){
     case 0:
       Navigator.of(context).push(MaterialPageRoute(
     builder:(context)=>Settings(item),
     ));
     break;
     case 1:
       Navigator.of(context).push(MaterialPageRoute(
         builder:(context)=>Settings(item),
       ));
     break;
     case 2:
       Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(
         builder:(context)=>Settings(item),),
         (route)=>false,
       );


     }

 }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        leading: Image.asset("images/rides_icon@3x.png",color: Colors.orange,),
        title: Row(
            children:
            [
          Text("Togo",style: TextStyle(fontSize:20,color: Colors.black),),
          Text("Parts",style: TextStyle(fontSize:20,color: Colors.orange),),

         /* Text(
              "         "), //for space between text of app bar and icons of app bar
          Icon(
            Icons.notifications,
          ),
          Text("       "),
          Icon(Icons.message),
*/
          /* 
             DropdownButton<dynamic>(
                iconSize: 16.0,
                hint: Icon(Icons.more_vert),
        value: dropdownValue,
                items:listItem.map((dynamic value) {
          return DropdownMenuItem<dynamic>(
            value: value,
            child: Text(
              value,
              style: TextStyle(fontSize:14),
            ),
          );
        }).toList(),
        // Step 5.
        onChanged: (dynamic? newValue) {
          setState(() {
            dropdownValue = newValue!;
          });
        },
      ),*/
            ]),
        actions: [
          Icon(Icons.notifications,size: 24.0,),
          Text("    "),
          Icon(Icons.message,size: 24.0,),
          PopupMenuButton<int>(
            iconSize: 30.0,
            icon: Icon(Icons.more_vert),
            position:PopupMenuPosition.under,
            onSelected: (item)=> onSelected(context,item),
              itemBuilder: (context) {
                return
                  [
                    PopupMenuItem<int>(value:0,child: Text(
                      "Settings", style: TextStyle(fontSize: 20),)),
                    PopupMenuItem<int>(value: 1,child: Text(
                      "Swtch Country", style: TextStyle(fontSize: 20),)),
                    PopupMenuItem<int>(value: 2,
                        child: Text("Log In", style: TextStyle(fontSize: 20),)),
                  ];
              },

          )

        ],


      ),

        body:Padding(
          padding: const EdgeInsets.only(top:14.0),
          child: ListView.separated(
            itemCount:list.length,
            separatorBuilder: (BuildContext context, int index) => const Divider(),
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Text(list[index],style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                leading: list1[index],
                onTap: (){
Navigator.push(context, MaterialPageRoute(builder: (context)=>Details(index)));


                },
              );
            },
          ),),

    );


  }
}

