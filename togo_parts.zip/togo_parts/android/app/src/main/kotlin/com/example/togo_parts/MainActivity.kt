package com.example.togo_parts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
